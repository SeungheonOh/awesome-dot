# Setup guide

In the fictional Maple client, open Help from the main menu. This bundle contains documentation only. See the [interface colours](../assets/Interface%20Colors.txt).

[Back to the start](../Start%20here.md)
