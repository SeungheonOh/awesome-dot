# Troubleshooting guide

If the help viewer is unavailable, read these UTF-8 files in a plain-text editor. Check the [release notes](../notes/release-notes.md) and [keyboard shortcuts](../reference/Keyboard%20shortcuts.txt).

[Back to the start](../Start%20here.md)
