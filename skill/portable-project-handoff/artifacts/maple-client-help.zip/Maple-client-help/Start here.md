# Maple client help

A fictional client-help handoff for Rowan Alder. The app itself is not included.

- [Setup guide](docs/setup-guide.md)
- [Troubleshooting guide](docs/troubleshooting-guide.md)
- [Interface colours](assets/Interface%20Colors.txt)
- [Release notes](notes/release-notes.md)
- [Keyboard shortcuts](reference/Keyboard%20shortcuts.txt)

Read both guides: setup and troubleshooting answer different questions.
