# Release notes

This fictional 2.4 help refresh uses the Help menu label consistently.

Read the [setup guide](../docs/setup-guide.md) before the [troubleshooting guide](../docs/troubleshooting-guide.md).
